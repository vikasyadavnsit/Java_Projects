package com.battleramp.springBootJDK14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJdk14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
